> v1.0.4
> - Update for Valheim 0.216.9
>
> v1.0.3
> - Update to fix Harmony bug found in ItemManager.
>
> v1.0.2
> - Update for Mistlands
>
> v1.0.1
> - Update ServerSync and Item/PieceManagers internally
>
> v1.0.0
> - Initial Release