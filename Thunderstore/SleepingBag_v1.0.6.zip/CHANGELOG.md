> v1.0.6
> - Prevent message from showing even when you were allowed to sleep
> - Register an effect in ZNetScene that wasn't before (like it should have been)
> - Pixelate the bed's texture at runtime to fit the game's style
> - Update internal managers to get latest benefits (optimizations, etc)
> - Will likely remake the assets for the sleeping bag in the future to better fit the game's style and maybe add a "replacement"
    model for when you have Smoothbrain's Backpacks mod installed.
>
> v1.0.5
> - Update for Valheim 0.217.22
>
> v1.0.4
> - Update for Valheim 0.216.9
>
> v1.0.3
> - Update to fix Harmony bug found in ItemManager.
>
> v1.0.2
> - Update for Mistlands
>
> v1.0.1
> - Update ServerSync and Item/PieceManagers internally
>
> v1.0.0
> - Initial Release